document.addEventListener('DOMContentLoaded', function() {
  const size = 5
  const board = []
  const gameBoard = document.getElementById('gameBoard')
  let playerName = ''
  let waterAmount = 6
  let actionCount = 0
  let playerPosition = { x: Math.floor(size / 2), y: Math.floor(size / 2) }

  const pNameInput = document.getElementById('playerName')
  const pNameDis = document.getElementById('playerNameDisplay').querySelector('h2')
  const waterDis = document.getElementById('waterLevel')

  let itemsFound = { item1: false, item2: false, item3: false }

  function start() {
    playerName = pNameInput.value || 'Explorer'
    pNameInput.style.display = 'none'
    document.getElementById('playerSetup').style.display = 'none'
    pNameDis.innerText = playerName
    initBoard()
    updateWater()
  }

  function initBoard() {
    for (let i = 0; i < size; i++) {
      let row = []
      let tr = document.createElement('tr')
      for (let j = 0; j < size; j++) {
        let td = document.createElement('td')
        td.addEventListener('click', () => handleCellClick(i, j))
        tr.appendChild(td)
        row.push({
          hasOasis: false,
          isTrueOasis: false,
          hasItem: null,
          revealed: false
        })
      }
      gameBoard.appendChild(tr)
      board.push(row)
    }
    putSpecialItems()
    placePlayer()
    updateWater()
  }

  function updateWater() {
    waterDis.textContent = waterAmount.toString() + ' units'
  }

  function decWaterAmount() {
    actionCount++
    if (actionCount >= 3) {
        waterAmount--
        actionCount = 0
        updateWater()
        if (waterAmount <= 0) {
            alert(playerName + ' has run out of water! Game over.')
            resetGame()
        }
    }
}

function resetGame() {
  
    document.location.reload()
}


  function putSpecialItems() {
    let trueOases = 3
    for (let n = 0; n < 4; n++) {
      placeRandom('oasis', n < trueOases)
    }
    ['item1', 'item2', 'item3'].forEach(item => placeRandom(item))
  }

  function placeRandom(type, isTrue) {
    let i, j
    do {
      i = Math.floor(Math.random() * size)
      j = Math.floor(Math.random() * size)
    } while (board[i][j].hasOasis || board[i][j].hasItem)
    board[i][j][type === 'oasis' ? 'hasOasis' : 'hasItem'] = type
    if (type === 'oasis') {
      board[i][j].isTrueOasis = isTrue
    }
    gameBoard.rows[i].cells[j].classList.add(type)
  }

  function placePlayer() {
      gameBoard.rows[playerPosition.x].cells[playerPosition.y].classList.add('player')
  }

  function handleCellClick(i, j) {
      if (i === playerPosition.x && j === playerPosition.y) {
          digTile(i, j)
      } else if (isAdjacent(i, j)) {
          movePlayer(i, j)
      }
  }

  function isAdjacent(i, j) {
      return Math.abs(playerPosition.x - i) + Math.abs(playerPosition.y - j) === 1
  }

  function movePlayer(i, j) {
      gameBoard.rows[playerPosition.x].cells[playerPosition.y].classList.remove('player', 'player-on-oasis')
      playerPosition.x = i
      playerPosition.y = j
      updateCell(i, j)
      decWaterAmount()
  }

  function digTile(i, j) {
    const cell = board[i][j]
    cell.revealed = true
    updateCell(i, j)
  
    if (cell.isTrueOasis) {
      waterAmount = 6
      alert('You found a true oasis! Water supply refilled.')
    }
  
    if (cell.hasItem) {
      itemsFound[cell.hasItem] = true
      setTimeout(() => {  
        checkWin()
      }, 100)
    }
  
    decWaterAmount()
  }
  
  function checkWin() {
    if (Object.values(itemsFound).every(status => status)) {
      alert(playerName + ' has found all items and won the game!')
      resetGame()
    }
  }
  
  function updateCell(i, j) {
      const cell = board[i][j]
      const td = gameBoard.rows[i].cells[j]
      td.className = ''

      if (cell.hasOasis && cell.revealed) {
        td.classList.add(cell.isTrueOasis ? 'true-oasis' : 'drought')
    } else if (cell.hasOasis) {
        td.classList.add('oasis')
    }

    
    if (cell.hasItem && cell.revealed) {
        switch(cell.hasItem) {
            case 'item1':
                td.classList.add('ritem1')
                break
            case 'item2':
                td.classList.add('ritem2')
                break
            case 'item3':
                td.classList.add('ritem3')
                break
            default:
                break
        }
    } else if (cell.hasItem) {
        td.classList.add('hidden-item')
    }


    if (i === playerPosition.x && j === playerPosition.y) {
        td.classList.add('player')
    }
}

window.startGame = start
})

